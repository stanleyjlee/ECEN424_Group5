import java.net.* ;
import java.util.ArrayList;

/**
 *  A simple datagram client
 *  Shows how to send and receive UDP packets in Java
 */
public class DatagramClient
{
   private final static int PACKETSIZE = 100 ;

   public static void main( String args[] )
   {
      // Check the arguments
      if( args.length != 3 )
      {
         System.out.println( "usage: java DatagramClient host port" ) ;
         return ;
      }

      if(args[2].length() > 50 || args[2].isEmpty()){
         System.out.println( "Enter a Valid String" ) ;
         return ;
      }

      DatagramSocket socket = null ;

      try
      {
         // Convert the arguments first, to ensure that they are valid
         InetAddress host = InetAddress.getByName( args[0] ) ;
         int port         = Integer.parseInt( args[1] ) ;
         String inputText = args[2];
         int inputTextLength = args[2].length();

         // Construct the socket
         socket = new DatagramSocket() ;

         //Construct Data String Array
         ArrayList<String> stringList = new ArrayList<String>();

         int arrIndex = 1;
         for(int i = 0; i < inputTextLength; i+=5){
            String strOut = inputText.substring(i,i+4);
            stringList.set(arrIndex, strOut);
            arrIndex++;
         }
         stringList.set(0, Integer.toString(arrIndex));

         for(int i = 0; i < stringList.size(); i++){
            // Construct the datagram packet
            byte [] data = stringList.get(i).getBytes() ;
            DatagramPacket packet = new DatagramPacket( data, data.length, host, port ) ;

            // Send it
            socket.send( packet ) ;

            // Set a receive timeout, 2000 milliseconds
            socket.setSoTimeout( 2000 ) ;

            // Prepare the packet for receive
            packet.setData( new byte[PACKETSIZE] ) ;

            // Wait for a response from the server
            socket.receive( packet ) ;

            // Print the response
            System.out.println( new String(packet.getData()) ) ;
         }
         
      }
      catch( Exception e )
      {
         System.out.println( e ) ;
      }
      finally
      {
         if( socket != null )
            socket.close() ;
      }
   }
}


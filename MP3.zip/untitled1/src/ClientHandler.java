import java.io.*;
import java.net.*;

public class ClientHandler implements Runnable {
    private Socket connectionSocket;

    //constructor
    public ClientHandler(Socket connectionSocket) {
        this.connectionSocket = connectionSocket;
    }

    @Override
    public void run() {
        try {
            //input and output streams for the client's Socket connection
            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
            DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());

            //IP address of the client
            InetAddress clientAddress = connectionSocket.getInetAddress();
            System.out.println("Received connection from: " + clientAddress.getHostAddress());

            String clientSentence;
            while ((clientSentence = inFromClient.readLine()) != null) {
                if (clientSentence.equals("./disconnect")) {
                    break;
                }
                System.out.println("Received message from " + clientAddress.getHostAddress() + ": " + clientSentence);

                String capitalizedSentence = clientSentence.toUpperCase() + '\n';
                outToClient.writeBytes(capitalizedSentence);
            }

            // Close the connection when client disconnects
            connectionSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}



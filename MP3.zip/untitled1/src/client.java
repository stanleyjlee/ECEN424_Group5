import java.io.*;
import java.net.*;

public class client {
    public static void main(String[] args) throws Exception{
        String sentence;
        String modifiedSentence;

        if (args.length < 2) {
            System.out.println(InetAddress.getLocalHost());
            System.out.println("Usage: java client <server ip> <server port>");
            System.exit(1);
        }

        try {
            // Parse the server port and max clients as integers
            String serverIP = args[0];
            int serverPort = Integer.parseInt(args[1]);

            // Use the parsed values for your application logic
            System.out.println("Server IP: " + serverIP);
            System.out.println("Server Port: " + serverPort);
            System.out.println(InetAddress.getLocalHost());

            while(true){
                Socket clientSocket = new Socket(serverIP, serverPort);

                BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));

                DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());

                BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                sentence = inFromUser.readLine();

                if(sentence.equals("./disconnect")){
                    break;
                }

                outToServer.writeBytes(sentence + '\n');

                modifiedSentence = inFromServer.readLine();

                System.out.println("FROM SERVER:" + modifiedSentence);

                clientSocket.close();
            }


        } catch (NumberFormatException e) {
            System.out.println("Error: Server port and max clients should be integers.");
            System.exit(1);
        }
    }
}
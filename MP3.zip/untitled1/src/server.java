import java.io.*;
import java.net.*;

public class server {
    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.out.println("Usage: java Server <server port>");
            System.exit(1);
        }

        try {
            // Parse server port as an integer
            int serverPort = Integer.parseInt(args[0]);

            System.out.println("Server Port: " + serverPort);
            // Creating server socket to listen for incoming client connections
            ServerSocket welcomeSocket = new ServerSocket(serverPort);

            while (true) {
                Socket connectionSocket = welcomeSocket.accept();

                // Start a new thread to handle the clients
                Thread clientThread = new Thread(new ClientHandler(connectionSocket));
                clientThread.start();
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Server port should be an integer.");
            System.exit(1);
        }
    }
}


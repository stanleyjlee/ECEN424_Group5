public class MultithreadingDemo extends Thread{
    private int value; // Shared value
    private int[][] m1 = new int[20][20];
    private int[][] m2 = new int[20][20];

    public MultithreadingDemo(int value, int[][]m1, int[][]m2) {
        this.value = value;
        this.m1 = m1;
        this.m2 = m2;
    }



    public void run()
    {
        try {
            // Displaying the thread that is running
            System.out.println(
                    "Thread " + Thread.currentThread().getId()
                            + " is running");


        }
        catch (Exception e) {
            // Throwing an exception
            System.out.println("Exception is caught");
        }
    }

}
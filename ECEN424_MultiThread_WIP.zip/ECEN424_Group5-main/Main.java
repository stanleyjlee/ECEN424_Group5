import java.util.Random;

public class Main {
    public static void RandomMatrix(int size, int[][] matrix){
        Random random = new Random(); // Random number generator

        // Populate the matrix with random numbers
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                matrix[i][j] = random.nextInt(100); // Generate a random integer between 0 and 99
            }
        }

        // Optional: Print the matrix to verify
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println(); // New line for each row
        }
    }

    public static void multMatrix(int[][] C, int[][] A, int[][] B) {
        // Assuming square matrices of size 4x4
        int n = A.length; // Assuming A is a square matrix for simplicity

        // Initialize C as a zero matrix
        createZeroMatrix(C);

        // Perform matrix multiplication
        for (int i = 0; i < n; ++i) { // Iterate over rows of A
            for (int j = 0; j < n; ++j) { // Iterate over columns of B
                for (int k = 0; k < n; ++k) { // Dot product of ith row of A and jth column of B
                    C[i][j] += A[i][k] * B[k][j];
                }
            }
        }
    }

    public static void createZeroMatrix(int[][] matrix) {
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) { // Use matrix[i].length for column size
                matrix[i][j] = 0;
            }
        }
    }

    public static void main(String[] args){

        int size = 20; // Size of the matrix
        int[][] m1 = new int[size][size];
        int[][] m2 = new int[size][size];
        int[][] result = new int[size][size];

        System.out.println("Matrix 1");
        RandomMatrix(size, m1);

        System.out.println("Matrix 2");
        RandomMatrix(size, m2);

        MultithreadingDemo t1 = new MultithreadingDemo(0, m1, m2);
        MultithreadingDemo t2 = new MultithreadingDemo(4, m1, m2);
        MultithreadingDemo t3 = new MultithreadingDemo(8, m1, m2);
        MultithreadingDemo t4 = new MultithreadingDemo(12, m1, m2);
        MultithreadingDemo t5 = new MultithreadingDemo(16, m1, m2);
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();

        multMatrix(result, m1, m2);

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                System.out.print(result[i][j] + " ");
            }
            System.out.println(); // New line for each row
        }

    }
}
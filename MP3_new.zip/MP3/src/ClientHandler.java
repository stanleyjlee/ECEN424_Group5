import java.io.*;
import java.net.*;
import java.util.concurrent.Semaphore;

//public class ClientHandler implements Runnable {
//    private Socket connectionSocket;
//    private String message;
//
//    //constructor
//    public ClientHandler(Socket connectionSocket, String message) {
//        this.connectionSocket = connectionSocket;
//        this.message = message;
//    }
//
//    @Override
//    public void run() {
//        try {
//            //input and output streams for the client's Socket connection
//            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
//            DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
//
//            //IP address of the client
//            InetAddress clientAddress = connectionSocket.getInetAddress();
//            System.out.println("Received connection from: " + clientAddress.getHostAddress());
//            outToClient.writeBytes(message);
//
//
//            String clientSentence;
//            while ((clientSentence = inFromClient.readLine()) != null) {
//                if (clientSentence.equals("./disconnect")) {
//                    break;
//                }
//                System.out.println("Received message from " + clientAddress.getHostAddress() + ": " + clientSentence);
//
//                String capitalizedSentence = clientSentence.toUpperCase() + '\n';
//                outToClient.writeBytes(capitalizedSentence);
//            }
//
//            // Close the connection when client disconnects
//            connectionSocket.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}

class ClientHandler implements Runnable {
    private Socket connectionSocket;
    private String message;
    private Semaphore semaphore;

    public ClientHandler(Socket connectionSocket, String message, Semaphore semaphore) {
        this.connectionSocket = connectionSocket;
        this.message = message;
        this.semaphore = semaphore;
    }

    @Override
    public void run() {
        try {
            // Acquire permit from the semaphore
            semaphore.acquire();

            // Process client request
            InetAddress clientAddress = connectionSocket.getInetAddress();
            System.out.println("Received connection from: " + clientAddress.getHostAddress());
            System.out.println("Sending message to " + clientAddress.getHostAddress() + ": " + message);

            // Send message to the client
            DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
            outToClient.writeBytes(message + '\n');

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } finally {
            try {
                // Release the semaphore permit
                semaphore.release();
                connectionSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}


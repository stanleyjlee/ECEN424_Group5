//import java.io.*;
//import java.net.*;
//
//public class server {
//    public static void main(String[] args) throws Exception {
//        if (args.length < 2) {
//            System.out.println("Usage: java Server <server port> <message>");
//            System.exit(1);
//        }
//
//        try {
//            // Parse server port as an integer
//            int serverPort = Integer.parseInt(args[0]);
//            String message = args[1];
//
//            System.out.println("Server Port: " + serverPort);
//            System.out.println("Message: " + message);
//            // Creating server socket to listen for incoming client connections
//            ServerSocket welcomeSocket = new ServerSocket(serverPort);
//
//            while (true) {
//                Socket connectionSocket = welcomeSocket.accept();
//
//                // Start a new thread to handle the clients
//                Thread clientThread = new Thread(new ClientHandler(connectionSocket, message));
//                clientThread.start();
//            }
//        } catch (NumberFormatException e) {
//            System.out.println("Error: Server port should be an integer.");
//            System.exit(1);
//        }
//    }
//}

import java.io.*;
import java.net.*;
import java.util.concurrent.Semaphore;

public class server {
    public static void main(String[] args) {
        if (args.length < 3) {
            System.out.println("Usage: java Server <server port> <max clients> <message>");
            System.exit(1);
        }

        try {
            // Parse server port and max clients as integers
            int serverPort = Integer.parseInt(args[0]);
            int maxClients = Integer.parseInt(args[1]);
            String message = args[2];

            System.out.println("Server Port: " + serverPort);
            System.out.println("Max Clients: " + maxClients);
            System.out.println("Message: " + message);

            // Semaphore to limit the number of clients
            Semaphore semaphore = new Semaphore(maxClients);

            // Creating server socket to listen for incoming client connections
            ServerSocket welcomeSocket = new ServerSocket(serverPort);

            while (true) {
                // Accept incoming client connections
                Socket connectionSocket = welcomeSocket.accept();

                // Start a new thread to handle the clients
                Thread clientThread = new Thread(new ClientHandler(connectionSocket, message, semaphore));
                clientThread.start();
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Server port and max clients should be integers.");
            System.exit(1);
        } catch (IOException ex) {
            System.out.println("Error: Unable to create server socket.");
            ex.printStackTrace();
            System.exit(1);
        }
    }
}
